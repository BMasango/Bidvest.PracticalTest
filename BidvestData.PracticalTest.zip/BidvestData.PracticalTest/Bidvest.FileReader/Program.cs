﻿using Bidvest.Core.Converts;
using System;

namespace Bidvest.FileReader
{
    class Program
    {
        static void Main(string[] args)
        {
            var fileContent = Core.FileReader.ReadFile("D:/VS Projects/BidvestData.PracticalTest/TestFiles/BDG_Input.txt");
            if (fileContent.Result.Success)
            {
                var jsonString = DetailsConverter.ConvertToJson(fileContent.Result.Data);
                Core.FileReader.WriteToFile("D:/VS Projects/BidvestData.PracticalTest/TestFiles/BDG_Output.json", jsonString);

                Console.WriteLine("File imported successfully.");
            }
            else {
                foreach (var error in fileContent.Result.Messages)
                {
                    Console.WriteLine(error);
                }
            }

            Console.ReadLine();
        }
    }
}
