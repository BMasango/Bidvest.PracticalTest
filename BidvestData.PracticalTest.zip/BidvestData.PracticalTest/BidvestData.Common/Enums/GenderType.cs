﻿public enum GenderType { 
    MALE,
    FEMALE
}