﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BidvestData.Common.Services
{
    public interface IServiceBase
    {
    }
}
