﻿using Bidvest.Core;
using BidvestData.Common.Models;
using BidvestData.Common.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bidvest.API.Services
{
    public class PersonService : IPersonService
    {
        private string path = "D:/VS Projects/BidvestData.PracticalTest/TestFiles/BDG_Output.json";
        
        public List<PersonalDetails> PersonelData { get; private set; }

        public async Task<Resultant<List<PersonalDetails>>> GetAllPersonel()
        {
            Resultant<List<PersonalDetails>> result = new Resultant<List<PersonalDetails>>();

            try
            {
                var fileContent = await FileReader.ReadFile(path);
                if (!fileContent.Success)
                {
                    result.Messages.AddRange(fileContent.Messages);
                    return result;
                }

                var jsonString = fileContent.Data.FirstOrDefault();
                if (string.IsNullOrEmpty(jsonString))
                {
                    result.Messages.Add("No data to read from.");
                    return result;
                }

                PersonelData = JsonConvert.DeserializeObject<List<PersonalDetails>>(jsonString);
                result.Data = new List<PersonalDetails>();
                result.Data.AddRange(PersonelData);
            }
            catch (Exception ex)
            {
                result.Messages.Add($"An error occurred while getting all the personel information.");
                result.Messages.Add($"See exception message: {ex.Message}");
            }

            return result;
        }

        public async Task<Resultant> UpdatePerson(PersonalDetails person)
        {
            Resultant result = new Resultant();

            try
            {
                var oldPerson = PersonelData.FirstOrDefault(x => x.Id == person.Id);
                if (oldPerson ==  null)
                {
                    result.Messages.Add($"No person found with ID {person.Id}.");
                    return result;
                }

                oldPerson.FirstName = person.FirstName;
                oldPerson.Surname = person.Surname;
                oldPerson.Email = person.Email;
                oldPerson.IPAddress = person.IPAddress;

                var jsonString = JsonConvert.SerializeObject(PersonelData);
                await FileReader.WriteToFile(path, jsonString);
            }
            catch (Exception ex)
            {
                result.Messages.Add($"An error occurred while updating {person.FirstName} {person.Surname} details.");
                result.Messages.Add($"See exception message: {ex.Message}");
            }

            return result;
        }
    }
}
